import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../models/reminder.dart';
import '../state/reminder_controller.dart';

class EditReminderScreen extends StatefulWidget {
  final Reminder? existing;

  const EditReminderScreen({super.key, this.existing});

  @override
  State<EditReminderScreen> createState() => _EditReminderScreenState();
}

class _EditReminderScreenState extends State<EditReminderScreen> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _titleCtrl;
  late TextEditingController _descCtrl;
  DateTime? _selectedDateTime;

  bool get isEditing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    _titleCtrl = TextEditingController(text: widget.existing?.title ?? '');
    _descCtrl =
        TextEditingController(text: widget.existing?.description ?? '');

    _selectedDateTime = widget.existing?.dateTime ?? DateTime.now();
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDateTime() async {
    final now = DateTime.now();
    final initialDate = _selectedDateTime ?? now;

    final date = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: now.subtract(const Duration(days: 1)),
      lastDate: now.add(const Duration(days: 365)),
      helpText: 'Selecciona la fecha',
    );

    if (date == null) return;

    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(initialDate),
      helpText: 'Selecciona la hora',
    );

    if (time == null) return;

    setState(() {
      _selectedDateTime = DateTime(
        date.year,
        date.month,
        date.day,
        time.hour,
        time.minute,
      );
    });
  }

  String _formatDateTime(DateTime? dt) {
    if (dt == null) return 'Sin fecha seleccionada';

    const meses = [
      'enero',
      'febrero',
      'marzo',
      'abril',
      'mayo',
      'junio',
      'julio',
      'agosto',
      'septiembre',
      'octubre',
      'noviembre',
      'diciembre',
    ];

    final dia = dt.day;
    final mes = meses[dt.month - 1];
    final hora = dt.hour.toString().padLeft(2, '0');
    final min = dt.minute.toString().padLeft(2, '0');

    return '$dia de $mes, $hora:$min hrs';
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedDateTime == null) return;

    final controller = context.read<ReminderController>();
    final id = widget.existing?.id ?? const Uuid().v4();

    final reminder = Reminder(
      id: id,
      title: _titleCtrl.text.trim(),
      description: _descCtrl.text.trim(),
      dateTime: _selectedDateTime!,
      status: widget.existing?.status ?? ReminderStatus.pending,
    );

    if (isEditing) {
      await controller.updateReminder(reminder);
    } else {
      await controller.addReminder(reminder);
    }

    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final titleText = isEditing ? 'Editar recordatorio' : 'Nuevo recordatorio';

    return Scaffold(
      appBar: AppBar(
        title: Text(titleText),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Título',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _titleCtrl,
                  style: const TextStyle(fontSize: 18),
                  decoration: const InputDecoration(
                    hintText: 'Ej: Estirar cuello',
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Escribe un título';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                const Text(
                  'Descripción (opcional)',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _descCtrl,
                  style: const TextStyle(fontSize: 18),
                  maxLines: 3,
                  decoration: const InputDecoration(
                    hintText: 'Ej: Girar hombros hacia atrás 10 veces',
                  ),
                ),
                const SizedBox(height: 24),
                const Text(
                  'Fecha y hora',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.access_time, size: 24),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _formatDateTime(_selectedDateTime),
                          style: const TextStyle(fontSize: 18),
                        ),
                      ),
                      TextButton(
                        onPressed: _pickDateTime,
                        child: const Text(
                          'Cambiar',
                          style: TextStyle(fontSize: 18),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _save,
                    child: Text(
                      isEditing
                          ? 'Guardar cambios'
                          : 'Crear recordatorio',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
